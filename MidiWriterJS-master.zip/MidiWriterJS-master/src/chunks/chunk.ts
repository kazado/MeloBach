interface Chunk {
    type: number[];
    size: number[];
}

export {Chunk};
